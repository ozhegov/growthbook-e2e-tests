__turbopack_load_page_chunks__("/projects", [
  "static/chunks/db896c170ca89a8e.js",
  "static/chunks/4b19718d61e839ba.js",
  "static/chunks/e695abbe48d02913.js",
  "static/chunks/801787d86683faf7.js",
  "static/chunks/695e9cc71e02fb08.js",
  "static/chunks/c607247506bc6686.js",
  "static/chunks/8057307b8958d870.js",
  "static/chunks/7097652203c400d0.js",
  "static/chunks/732373a1322c234b.js",
  "static/chunks/dfc90f7d7ae8ffac.js",
  "static/chunks/8c81fd3a6dbad9d1.js",
  "static/chunks/a6380b2bcd15d4c6.js",
  "static/chunks/932d535f90132b7e.css",
  "static/chunks/c6d67ddefa58a4e5.css",
  "static/chunks/turbopack-8ea0a46c41c4cddc.js"
])
