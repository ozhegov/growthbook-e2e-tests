__turbopack_load_page_chunks__("/settings/tags", [
  "static/chunks/4c3a687f9767a18e.js",
  "static/chunks/4b19718d61e839ba.js",
  "static/chunks/801787d86683faf7.js",
  "static/chunks/69e6cca6a68bfa34.js",
  "static/chunks/e9cce58796bcbcec.js",
  "static/chunks/5a1d64fb9b6f3cd5.js",
  "static/chunks/7097652203c400d0.js",
  "static/chunks/a6380b2bcd15d4c6.js",
  "static/chunks/732373a1322c234b.js",
  "static/chunks/8057307b8958d870.js",
  "static/chunks/b6d71ca788c7183f.js",
  "static/chunks/932d535f90132b7e.css",
  "static/chunks/de609aea05cc05b3.css",
  "static/chunks/turbopack-4b13b1f4d7b5c453.js"
])
