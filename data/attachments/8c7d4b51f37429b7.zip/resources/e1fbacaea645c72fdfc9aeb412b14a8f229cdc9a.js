__turbopack_load_page_chunks__("/settings/tags", [
  "static/chunks/032634236df9e83f.js",
  "static/chunks/4b19718d61e839ba.js",
  "static/chunks/801787d86683faf7.js",
  "static/chunks/69e6cca6a68bfa34.js",
  "static/chunks/e9cce58796bcbcec.js",
  "static/chunks/f7dc77f69a5ca35e.js",
  "static/chunks/7097652203c400d0.js",
  "static/chunks/a6380b2bcd15d4c6.js",
  "static/chunks/732373a1322c234b.js",
  "static/chunks/8057307b8958d870.js",
  "static/chunks/b6d71ca788c7183f.js",
  "static/chunks/932d535f90132b7e.css",
  "static/chunks/c6d67ddefa58a4e5.css",
  "static/chunks/turbopack-b0a847669d2f1e9a.js"
])
