__turbopack_load_page_chunks__("/importing", [
  "static/chunks/70a29df4fe10d62e.js",
  "static/chunks/98fd40d803682425.js",
  "static/chunks/4b19718d61e839ba.js",
  "static/chunks/801787d86683faf7.js",
  "static/chunks/8057307b8958d870.js",
  "static/chunks/a6380b2bcd15d4c6.js",
  "static/chunks/turbopack-da7555f1a27bea21.js"
])
